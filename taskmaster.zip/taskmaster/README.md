> # Task Master

> > ## Homepage

* Homepage Before Set username:

  <img src="screenshots/homeBeforeSetName.png" alt="Homepage" width="300"/>

* Homepage After Set username:

  <img src="screenshots/homeAfterSetName.png" alt="Homepage" width="300"/>

> > ## Setting page

* Settings Before Set username:

  <img src="screenshots/settingBeforeSave.png" alt="settingBeforeSave" width="300"/>

* Settings After Set username:
  
  <img src="screenshots/settingAfterSave.png" alt="settingAfterSave" width="300"/>

> > ## Add a Task page

  <img src="screenshots/2.png" alt="Add a Task page" width="300"/>

  <img src="screenshots/3.png" alt="Add a Task successfully" width="300"/>



> > ## All tasks page

  <img src="screenshots/4.png" alt="All tasks page" width="300"/>

> > ## Details page

  <img src="screenshots/details1.png" alt="Details page" width="300"/>

  <img src="screenshots/details2.png" alt="Details page" width="300"/>

  <img src="screenshots/details3.png" alt="Details page" width="300"/>

